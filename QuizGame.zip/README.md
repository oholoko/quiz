![IMG_20220424_123028](https://user-images.githubusercontent.com/101186072/164972232-3e71be81-f14f-4b1e-9704-7616a88c6a79.jpg)


![React](https://img.shields.io/badge/react-%2320232a.svg?style=for-the-badge&logo=react&logoColor=%2361DAFB)

# Quiz Game with ReactJs & TypeScript.
# Demo Versel: https://quiz-game-liart.vercel.app/

# Description

It is a simple game. where the player has one question with four answers but only one is correct. the player can ask for help 3 times and can only answer wrong 3 times otherwise will lose the match.

# Installation

* 1 - > git clone Ihttps://github.com/edilson258/QuizGame.git
* 2 - > cd QuizGame
* 3 - > yarn install
* 4 - > yarn start

# Future of the project

* Allow multiple topics 
* Add a route to allow user choose a topic
* Save the progress of the user
* Show the statistics of the user
