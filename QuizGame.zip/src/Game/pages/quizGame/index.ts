export {default} from "./QuizCore"
